<html>
    <head>
        <title>File Upload</title>
    </head>
    <body>
        <form action="upload.php" method="POST" enctype="multipart/form-data">
            <input type="file" name="myfile">
            <input type="submit" name="submit">
        </form>
</body>
</html>