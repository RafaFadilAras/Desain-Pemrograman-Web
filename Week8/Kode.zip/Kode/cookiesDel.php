<?php
    setcookie("user","Polinema", time()-3600);
?>